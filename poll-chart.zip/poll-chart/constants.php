<?php

define('AG_POLL_CHART_DEBUG', 0);

define('AG_POLL_CHART_LOGGING', 1);

define('AG_POLL_CHART_PLUGIN_DIR', plugin_dir_path(__FILE__));