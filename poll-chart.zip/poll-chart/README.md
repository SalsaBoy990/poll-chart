# poll-chart
A Wordpress plugin. Create a poll and view results in a Google chart after voting
